import math


def entropy(examples, target):
        """Takes a list of examples and returns their entropy w.r.t. the target attribute"""
        possible_values = ['S', 'C']
        bucket = [0 for _ in possible_values]

        for example in examples:
            bucket[possible_values.index(example[target])] += 1

        
        #sprint(len(examples))
        total_examples = sum(bucket)
        entropy = 0
        for el in bucket:

            p_el = el / total_examples
            entropy += (p_el * math.log2(p_el) if p_el != 0 else 0)
        
        #print(-entropy)
        return -entropy if entropy != 0 else entropy


def information_gain(parent, children):
        """
        Takes a `parent` set and a subset `children` of the parent.
        Returns the information gain due to splitting `children` from `parent`.
        """
        total = len(parent)
        len_children = [len(child) for child in children]
        
        parent_entropy = entropy(parent, 1)
        children_entropy = []
        for child in children:
            children_entropy.append(entropy(child, 1))

        avg_entropy = 0
        for i in range(len(children)):
            avg_entropy += len_children[i]/total * children_entropy[i]
        

        print("Average entropy " + str(avg_entropy))
        
        return parent_entropy - avg_entropy
    

domains = [
    [1, 2, 3],
    ['S', 'C']
]



def plurality_value(examples, target):
        values = {}

        for possible_value in domains[target]:
            values[possible_value] = 0

        for example in examples:
            values[example[target]] += 1
        

        max = -1
        pl_value = None

        for k, v in values.items():
            if v > max:
                max = v
                pl_value = k
        
        return pl_value
        

def split_on_attr(examples, attribute):
        
        num_splits = len(domains[attribute])
        
        children = {}

        for possible_value in domains[attribute]:
            children[possible_value] = list()

        
        for example in examples:
            children[example[attribute]].append(example)
        

        children_list = []

        for key, value in children.items():
            children_list.append(value)

        return children_list


def split_on_attr_dict(examples, attribute):

        children = {}

        for possible_value in domains[attribute]:  # Create a list of each possible child
            children[possible_value] = list()

        
        for example in examples:
            children[example[attribute]].append(example)  # Add the record to suitable bucket

        return children

parent =  [
    [1, 'S'],
    [2, 'S'],
    [3, 'S'],
    [4, 'S'],
    [5, 'S'],
    [6, 'S'],
    [7, 'S'],
    [8, 'S'],
    [9, 'S'],
    [10, 'S'],
    [11, 'S'],
    [12, 'S'],
    [13, 'S'],
    [14, 'S'],
    [15, 'C'],
    [16, 'C'],
    [17, 'C'],
    [18, 'C'],
    [19, 'C'],
    [20, 'C'],
    [21, 'C'],
    [22, 'C'],
    [23, 'C'],
    [24, 'C'],
    [25, 'C'],
    [26, 'C'],
    [27, 'C'],
    [28, 'C'],
    [29, 'C'],
    [30, 'C'],
]

print(split_on_attr_dict(parent, 1))

# child1 = [
#     [1, 'S'],
#     [2, 'C'],
#     [3, 'C'],
#     [4, 'C'],
#     [5, 'C'],
#     [6, 'C'],
#     [7, 'C'],
#     [8, 'C'],
#     [9, 'C'],
#     [10, 'C'],
#     [11, 'C'],
#     [12, 'C'],
#     [13, 'C'],
# ]

# child2 = [
#     [1, 'S'],
#     [2, 'S'],
#     [3, 'S'],
#     [4, 'S'],
#     [5, 'S'],
#     [6, 'S'],
#     [7, 'S'],
#     [8, 'S'],
#     [9, 'S'],
#     [10, 'S'],
#     [11, 'S'],
#     [12, 'S'],
#     [13, 'S'],
#     [14, 'C'],
#     [15, 'C'],
#     [16, 'C'],
#     [17, 'C']
# ]

# print(entropy(parent, 1))
# print(entropy(child1, 1))
# print(entropy(child2, 1))
# print(information_gain(parent, [child1, child2]))